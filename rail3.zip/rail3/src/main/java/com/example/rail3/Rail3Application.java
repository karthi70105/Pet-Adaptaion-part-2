package com.example.rail3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Rail3Application {

	public static void main(String[] args) {
		SpringApplication.run(Rail3Application.class, args);
	}

}
